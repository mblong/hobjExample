# USAGE
# getNamesInFolder-r.sh directoryName extension
# creates the file names-r.o2m in directoryName that contains the names of
# files in the folder with the specified extension
# files are listed in reverse alphabetical order
# use this with oma's GETFILENAMES and NEXT commands
cd "$1"
#
ls -1 -r *.$2 > names-r.txt
#
wait
#
