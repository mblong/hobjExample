clear
% % calculate intensity lookup table

day='18026';
fuel='CH4/';
ktable=[];
expTable=[];
greenTargtTable=[];

run='D3';
sweep=1;
exposure=800e-6;
emis=.88;
fila_diam = .0155 ; % diameter in mm
pixel_size = 1/17.9;  % in mm
t0=1650;
getIntensityLookupTableHistogram
t1=[table(:,1) table(:,2)/exposure/1e3];

run='D5';
sweep=2;
exposure=800e-6;
emis=.88;
fila_diam = .0155 ; % diameter in mm
pixel_size = 1/17.9;  % in mm
t0=1650;
getIntensityLookupTableHistogram
t2=[table(:,1) table(:,2)/exposure/1e3];

run='L1';
sweep=3;
exposure=800e-6;
emis=.88;
fila_diam = .0155 ; % diameter in mm
pixel_size = 1/17.9;  % in mm
t0=1650;
getIntensityLookupTableHistogram
t3=[table(:,1) table(:,2)/exposure/1e3];

run='M1';
sweep=1;
exposure=800e-6;
emis=.88;
fila_diam = .0155 ; % diameter in mm
pixel_size = 1/17.9;  % in mm
t0=1650;
getIntensityLookupTableHistogram
t4=[table(:,1) table(:,2)/exposure/1e3];

format short g
[expTable greenTargtTable ktable]

figure
hold on
p1 = plot(t1(:,1),t1(:,2));
p2 = plot(t2(:,1),t2(:,2));
p3 = plot(t3(:,1),t3(:,2));
p4 = plot(t4(:,1),t4(:,2));
h=[p1;p2;p3;p4];
legend(h,'D3','D5','L1','M1');
hold off

