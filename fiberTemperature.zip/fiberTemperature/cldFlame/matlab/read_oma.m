function image = read_oma(name,isrgb)
% image = read_oma(name,isrgb)
% read in an oma binary file specified by name (a string)
% return a matrix containing the image 
% if isrgb is 1, then the oma file is assumed to be a
% color image, with red data in the first third of the rows
% followed by green, then blue
form = 'l';
fid = fopen(name,'r', form);
[nam,perm,machform,code] = fopen(fid);


%check for oma2 data file
header = fread(fid,30,'char');
str = char(header);
if(strncmp(str,'OMA2 Binary Data 1.0',length('OMA2 Binary Data 1.0')));
    nspecs = fread(fid,1,'int');
    nvalues = fread(fid,1,'int');
    nrulerchar = fread(fid,1,'int'); 
    specs = fread(fid,nspecs,'int');
    values = fread(fid,nvalues,'float');
    rulerchar = fread(fid,nrulerchar,'char');
    
    error =    fread(fid,1,'int');
    is_big_endian =fread(fid,1,'int');
    commentSize =   fread(fid,1,'int');
    extraSize =    fread(fid,1,'int');
    if(commentSize >0)
        comment = fread(fid,commentSize,'char');
    end
    if(extraSize >0)
        extra = fread(fid,extraSize,'float');
    end

    col = specs(2);
    row = specs(1);
    image = fread(fid,[col,row],'float32');
    image = image';

    [r,c] = size(image);
    
    if(specs(9) == 1)    % color image
        red = image(1:r/3,:);
        green = image(r/3+1:2*r/3,:);
        blue = image(2*r/3+1:r,:);
        image = red;
        image(:,:,2) = green;
        image(:,:,3) = blue;
    end
  
    return;
end

% this must be the old oma format
fclose(fid);
fid = fopen(name,'r', form);

header = fread(fid,256,'short');
% this value tells about the byte ordering
endian_type = header(227);
%this means little_endian
le = 32639;
%this is big_endian
be = 0;
if(endian_type == be)
    fclose(fid);
    form = 'b';
    fid = fopen(name,'r', form);
    header = fread(fid,256,'short');
end
col = header(8);
row = header(9);
 
% skip the data offset
image = fread(fid,80,'float32');

image = fread(fid,[col,row],'float32');
fclose(fid);
image = image';

[r,c] = size(image);

if(r ~= row)
    fid = fopen(name,'r', form);
    header = fread(fid,256,'short');
    image = fread(fid,80,'short');

    image = fread(fid,[col,row],'short');
    fclose(fid);
    image = image';
end
if(nargin == 2 && isrgb == 1)
    red = image(1:r/3,:);
    green = image(r/3+1:2*r/3,:);
    blue = image(2*r/3+1:r,:);
    image = red;
    image(:,:,2) = green;
    image(:,:,3) = blue;
end

    